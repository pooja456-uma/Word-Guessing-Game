package com.example.myfirstapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class LeaderboardActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard);

        // Predefined Top 3 Scores
        String[] topPlayers = {"Alice", "Bob", "E2245294"};
        int[] topScores = {100, 80, 40};

        // Find TextViews and update them
        ((TextView) findViewById(R.id.player1)).setText("1. " + topPlayers[0] + " - " + topScores[0] + " points");
        ((TextView) findViewById(R.id.player2)).setText("2. " + topPlayers[1] + " - " + topScores[1] + " points");
        ((TextView) findViewById(R.id.player3)).setText("3. " + topPlayers[2] + " - " + topScores[2] + " points");

        // Back button to return to MainActivity
        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(LeaderboardActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}

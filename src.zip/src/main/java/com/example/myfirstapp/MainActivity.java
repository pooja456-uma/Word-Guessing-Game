package com.example.myfirstapp;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    private EditText userInput;
    private TextView wordDisplay, scoreDisplay, userWelcome, timerDisplay;
    private Button btnCheckGuess, btnAskForLetters, btnAskForLength, btnGiveTip, btnViewLeaderboard, btnEndGame;
    private int score = 100;
    private String secretWord = "Pineapple"; // This will be updated by the FetchWordTask
    private int timeLeft = 60;
    private int incorrectGuesses = 0;
    private long startTime;
    private Handler handler = new Handler();
    private Runnable updateTimer;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // UI Elements
        userInput = findViewById(R.id.userInput);
        wordDisplay = findViewById(R.id.wordDisplay);
        scoreDisplay = findViewById(R.id.scoreDisplay);
        userWelcome = findViewById(R.id.userWelcome);
        timerDisplay = findViewById(R.id.timerDisplay);
        btnCheckGuess = findViewById(R.id.btnCheckGuess);
        btnAskForLetters = findViewById(R.id.btnAskForLetters);
        btnAskForLength = findViewById(R.id.btnAskForLength);
        btnGiveTip = findViewById(R.id.btnGiveTip);
        btnViewLeaderboard = findViewById(R.id.btnViewLeaderboard);
        btnEndGame = findViewById(R.id.btnEndGame);

        // Load saved username
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String userName = prefs.getString("username", "Player");
        userWelcome.setText("Welcome, " + userName + "!");

        // Display initial score
        scoreDisplay.setText("Score: " + score);

        // Fetch a new word from the server
        new FetchWordTask().execute();

        // Guess Check Button
        btnCheckGuess.setOnClickListener(v -> {
            String guess = userInput.getText().toString().trim();
            if (!guess.isEmpty()) {
                checkGuess(guess);
            } else {
                Toast.makeText(MainActivity.this, "Please enter a guess", Toast.LENGTH_SHORT).show();
            }
        });

        // Ask for Letters Button
        btnAskForLetters.setOnClickListener(v -> {
            if (score >= 5) {
                score -= 5;
                scoreDisplay.setText("Score: " + score);
                String letter = userInput.getText().toString().trim();
                if (!letter.isEmpty() && letter.length() == 1) {
                    int occurrences = countLetterOccurrences(letter.charAt(0));
                    wordDisplay.setText("The letter '" + letter + "' appears " + occurrences + " times.");
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a valid letter.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(MainActivity.this, "Not enough points!", Toast.LENGTH_SHORT).show();
            }
        });

        // Ask for Word Length Button
        btnAskForLength.setOnClickListener(v -> {
            if (score >= 5) {
                score -= 5;
                scoreDisplay.setText("Score: " + score);
                wordDisplay.setText("The word has " + secretWord.length() + " letters.");
            } else {
                Toast.makeText(MainActivity.this, "Not enough points!", Toast.LENGTH_SHORT).show();
            }
        });

        // Give Tip Button
        btnGiveTip.setOnClickListener(v -> {
            if (incorrectGuesses >= 5) {
                giveTip();
            } else {
                Toast.makeText(MainActivity.this, "You need 5 incorrect guesses to get a tip.", Toast.LENGTH_SHORT).show();
            }
        });

        // View Leaderboard Button
        btnViewLeaderboard.setOnClickListener(v -> {
            saveScoreToLeaderboard();
            Intent intent = new Intent(MainActivity.this, LeaderboardActivity.class);
            startActivity(intent);
        });

        // End Game Button
        btnEndGame.setOnClickListener(v -> gameOver());

        // Start the timer
        startTimer();
    }

    private void startTimer() {
        startTime = System.currentTimeMillis();
        updateTimer = new Runnable() {
            @Override
            public void run() {
                if (timeLeft > 0) {
                    timeLeft--;
                    int minutes = timeLeft / 60;
                    int seconds = timeLeft % 60;
                    timerDisplay.setText(String.format("Time Left: %02d:%02d", minutes, seconds));
                    handler.postDelayed(this, 1000);
                } else {
                    timerDisplay.setText("Time's up!");
                    gameOver();
                }
            }
        };
        handler.post(updateTimer);
    }

    private void checkGuess(String guess) {
        if (guess.equalsIgnoreCase(secretWord)) {
            wordDisplay.setText("Correct! The word was: " + secretWord);
            Toast.makeText(this, "You won!", Toast.LENGTH_SHORT).show();
            saveScoreToLeaderboard();
        } else {
            score -= 10;
            scoreDisplay.setText("Score: " + score);
            wordDisplay.setText("Incorrect! Try again.");
            incorrectGuesses++;
            if (score <= 0) {
                gameOver();
            }
        }
    }

    private void gameOver() {
        wordDisplay.setText("Game Over! The word was: " + secretWord);
        Toast.makeText(this, "You failed the attempt!", Toast.LENGTH_LONG).show();
        resetGame();
    }

    private int countLetterOccurrences(char letter) {
        int count = 0;
        for (char c : secretWord.toCharArray()) {
            if (c == letter) count++;
        }
        return count;
    }

    private void giveTip() {
        String tip = "A tropical fruit with spiky skin.";
        wordDisplay.setText("Here's a tip: " + tip);
    }

    private void resetGame() {
        score = 100;
        secretWord = "java";  // Reset word
        scoreDisplay.setText("Score: " + score);
        wordDisplay.setText("New game started!");
        incorrectGuesses = 0;
        startTime = System.currentTimeMillis();
        timeLeft = 60;
        handler.post(updateTimer);
    }

    private void saveScoreToLeaderboard() {
        SharedPreferences prefs = getSharedPreferences("LeaderboardPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt("lastScore", score);
        editor.apply();
    }

    private class FetchWordTask extends AsyncTask<Void, Void, String> {
        @Override
        protected String doInBackground(Void... voids) {
            try {
                URL url = new URL("https://example.com/getword");  // Change to actual API endpoint
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                reader.close();
                return response.toString();  // Assuming API returns the word
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String word) {
            if (word != null) {
                secretWord = word;
                wordDisplay.setText("Word Loaded: " + secretWord);  // For debugging
            } else {
                wordDisplay.setText("Failed to load word.");
            }
        }
    }
}

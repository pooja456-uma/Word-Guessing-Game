package com.example.myfirstapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class NameEntryActivity extends AppCompatActivity {

    private EditText etUserName;
    private Button btnStartGame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_name_entry);

        etUserName = findViewById(R.id.etUserName);
        btnStartGame = findViewById(R.id.btnStartGame);

        btnStartGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userName = etUserName.getText().toString().trim();

                if (!userName.isEmpty()) {
                    // Save name in SharedPreferences
                    SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("username", userName);
                    editor.apply();

                    // Start MainActivity
                    Intent intent = new Intent(NameEntryActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Close this activity
                } else {
                    Toast.makeText(NameEntryActivity.this, "Please enter a name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
